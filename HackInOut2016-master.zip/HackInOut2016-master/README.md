# HackInOut 2016 Project

## IoT based chatbot controlled CNC machine.

## What is this?
It is a miniature version of a Real time CNC machine, which students can use for educational purposes for school and colleges. It can pretty much do everything a real CNC machine can. It is operated via Chat bot which has many features like real time analytics of work and temperature and a personal assistant fore help.

## Pictures
<img src="http://challengepost-s3-challengepost.netdna-ssl.com/photos/production/software_photos/000/401/150/datas/gallery.jpg">
<img src="http://challengepost-s3-challengepost.netdna-ssl.com/photos/production/software_photos/000/401/152/datas/gallery.jpg">

## More Details
http://devpost.com/software/iot-based-facebook-chatbot-controlled-cnc-machine

# And yes, we won Best Hardware Hack - 2nd Prize @HackInOut 2016
