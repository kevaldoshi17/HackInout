#ka

import urllib2

urllib2.urlopen("http://inout-daxeelsoni.rhcloud.com/api/machine_status/off")